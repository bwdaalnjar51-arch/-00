<?php
require_once "config.php";
if(empty($_SESSION["student_id"])) { header("Location:index.php"); exit; }
$msg="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $code=trim($_POST["code"]??"");
    $q=$pdo->prepare("SELECT id,title,video_url FROM lessons WHERE access_code=? LIMIT 1");
    $q->execute([$code]); $lesson=$q->fetch();
    if($lesson) $_SESSION["lesson_id"]=$lesson["id"];
    else $msg="كود الدرس غير صحيح.";
}
$lessons=$pdo->query("SELECT id,title,video_url FROM lessons ORDER BY id DESC")->fetchAll();
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>الدروس</title><link rel="stylesheet" href="assets/style.css"></head><body>
<div class="wrap"><div class="top"><h1>الدروس</h1><a href="logout.php">خروج</a></div>
<div class="card"><h2>الدخول إلى درس بكود</h2><?php if($msg): ?><div class="error"><?=htmlspecialchars($msg)?></div><?php endif; ?>
<form method="post"><input name="code" placeholder="أدخل كود الدرس" required><button>فتح الدرس</button></form></div>
<?php foreach($lessons as $l): ?><div class="lesson"><h3><?=htmlspecialchars($l["title"])?></h3><form method="post"><input name="code" placeholder="كود الدرس" required><button>فتح</button></form></div><?php endforeach; ?>
</div></body></html>
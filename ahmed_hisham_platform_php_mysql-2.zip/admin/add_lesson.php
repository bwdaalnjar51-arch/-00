<?php
require_once "../config.php";
if(empty($_SESSION["admin"])) { header("Location:login.php"); exit; }
$title=trim($_POST["title"]??""); $code=trim($_POST["code"]??""); $video=trim($_POST["video"]??"");
if($title && $code && $video){ $q=$pdo->prepare("INSERT INTO lessons(title,access_code,video_url) VALUES(?,?,?)"); $q->execute([$title,$code,$video]); }
header("Location:index.php"); exit;
?>
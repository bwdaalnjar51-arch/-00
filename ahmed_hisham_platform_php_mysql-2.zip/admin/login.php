<?php
require_once "../config.php";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $u=$_POST["user"]??""; $p=$_POST["pass"]??"";
 if($u==="admin" && $p==="Admin@12345"){ $_SESSION["admin"]=true; header("Location:index.php"); exit; }
 $err="بيانات الإدارة غير صحيحة.";
}
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>دخول الإدارة</title><link rel="stylesheet" href="../assets/style.css"></head><body><div class="hero"><div class="card"><h1>دخول الإدارة</h1><?php if(isset($err)): ?><div class="error"><?=$err?></div><?php endif; ?><form method="post"><input name="user" placeholder="اسم المستخدم" required><input type="password" name="pass" placeholder="كلمة المرور" required><button>دخول</button></form></div></div></body></html>
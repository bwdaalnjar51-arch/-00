<?php
require_once "../config.php";
if(empty($_SESSION["admin"])) { header("Location:login.php"); exit; }
$logs=$pdo->query("SELECT * FROM logins ORDER BY id DESC")->fetchAll();
$lessons=$pdo->query("SELECT * FROM lessons ORDER BY id DESC")->fetchAll();
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>الإدارة</title><link rel="stylesheet" href="../assets/style.css"></head><body><div class="wrap">
<div class="top"><h1>لوحة الإدارة</h1><a href="logout.php">خروج</a></div>
<div class="card"><h2>إضافة درس</h2><form action="add_lesson.php" method="post"><input name="title" placeholder="اسم الدرس" required><input name="code" placeholder="كود الدخول" required><input name="video" placeholder="رابط الفيديو" required><button>إضافة الدرس</button></form></div>
<div class="card"><h2>تسجيلات الطلاب</h2><div class="table"><?php foreach($logs as $x): ?><p><?=htmlspecialchars($x["name"]." ".$x["father"]." ".$x["grandfather"])?> — طالب: <?=htmlspecialchars($x["student_no"])?> — ولي الأمر: <?=htmlspecialchars($x["parent_phone"])?></p><?php endforeach; ?></div></div>
<div class="card"><h2>الدروس الحالية</h2><?php foreach($lessons as $l): ?><p><?=htmlspecialchars($l["title"])?> — الكود: <b><?=htmlspecialchars($l["access_code"])?></b></p><?php endforeach; ?></div>
</div></body></html>
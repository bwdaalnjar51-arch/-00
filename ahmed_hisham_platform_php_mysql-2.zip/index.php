<?php
require_once "config.php";
$msg="";
if ($_SERVER["REQUEST_METHOD"]==="POST") {
    $name=trim($_POST["name"]??"");
    $father=trim($_POST["father"]??"");
    $grandfather=trim($_POST["grandfather"]??"");
    $student=trim($_POST["student"]??"");
    $parent=trim($_POST["parent"]??"");
    if($name && $father && $grandfather && $student && $parent){
        $q=$pdo->prepare("INSERT INTO logins(name,father,grandfather,student_no,parent_phone) VALUES(?,?,?,?,?)");
        $q->execute([$name,$father,$grandfather,$student,$parent]);
        $_SESSION["student_id"]=$pdo->lastInsertId();
        header("Location: lessons.php"); exit;
    } else $msg="من فضلك املأ جميع البيانات.";
}
?>
<!doctype html><html lang="ar" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>منصة مستر أحمد هشام</title><link rel="stylesheet" href="assets/style.css"></head><body>
<div class="hero"><div class="card">
<h1>منصة مستر أحمد هشام</h1><p>منصة تعليمية للطلاب</p>
<?php if($msg): ?><div class="error"><?=htmlspecialchars($msg)?></div><?php endif; ?>
<form method="post">
<input name="name" placeholder="الاسم" required>
<input name="father" placeholder="اسم الأب" required>
<input name="grandfather" placeholder="اسم الجد" required>
<input name="student" placeholder="رقم الطالب" required>
<input name="parent" placeholder="رقم ولي الأمر" required>
<button>دخول المنصة</button>
</form>
</div></div></body></html>
<?php
session_start();

$db_host = "localhost";
$db_name = "PUT_DATABASE_NAME_HERE";
$db_user = "PUT_DATABASE_USER_HERE";
$db_pass = "PUT_DATABASE_PASSWORD_HERE";

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    die("تعذر الاتصال بقاعدة البيانات. راجع بيانات config.php");
}
?>